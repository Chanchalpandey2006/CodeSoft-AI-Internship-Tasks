# Task 2 - Tic-Tac-Toe AI

A command-line Tic-Tac-Toe game where a human player competes against an AI agent.

## AI Algorithm
The computer uses the **Minimax algorithm**. It evaluates possible future game states and chooses the move with the best possible outcome for the AI, assuming the human also plays optimally.

## Features
- Human vs AI gameplay
- Win and draw detection
- Input validation
- Unbeatable Minimax-based decision making

## How to Run

```bash
python main.py
```

## Concepts Used
- Game theory
- Search algorithms
- Recursion
- Minimax
- Conditional logic
