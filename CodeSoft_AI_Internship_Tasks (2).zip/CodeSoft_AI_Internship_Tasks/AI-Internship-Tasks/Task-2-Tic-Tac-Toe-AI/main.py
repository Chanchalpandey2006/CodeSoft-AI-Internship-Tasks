"""
CodeSoft AI Internship - Task 2
Tic-Tac-Toe AI using Minimax
"""

import math


WINNING_LINES = (
    (0, 1, 2), (3, 4, 5), (6, 7, 8),
    (0, 3, 6), (1, 4, 7), (2, 5, 8),
    (0, 4, 8), (2, 4, 6),
)


def display_board(board):
    print("\n")
    for row in range(3):
        cells = board[row * 3:(row + 1) * 3]
        print(f" {cells[0]} | {cells[1]} | {cells[2]}")
        if row < 2:
            print("---+---+---")
    print()


def winner(board):
    for a, b, c in WINNING_LINES:
        if board[a] == board[b] == board[c] != " ":
            return board[a]
    if " " not in board:
        return "Draw"
    return None


def minimax(board, maximizing):
    result = winner(board)

    if result == "O":
        return 1
    if result == "X":
        return -1
    if result == "Draw":
        return 0

    if maximizing:
        best_score = -math.inf
        for i in range(9):
            if board[i] == " ":
                board[i] = "O"
                best_score = max(best_score, minimax(board, False))
                board[i] = " "
        return best_score

    best_score = math.inf
    for i in range(9):
        if board[i] == " ":
            board[i] = "X"
            best_score = min(best_score, minimax(board, True))
            board[i] = " "
    return best_score


def ai_move(board):
    best_score = -math.inf
    best_position = None

    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            score = minimax(board, False)
            board[i] = " "

            if score > best_score:
                best_score = score
                best_position = i

    board[best_position] = "O"


def player_move(board):
    while True:
        try:
            position = int(input("Choose a position (1-9): ")) - 1

            if position not in range(9):
                print("Please enter a number from 1 to 9.")
            elif board[position] != " ":
                print("That position is already taken.")
            else:
                board[position] = "X"
                return
        except ValueError:
            print("Please enter a valid number.")


def main():
    board = [" "] * 9

    print("=" * 45)
    print("             TIC-TAC-TOE AI")
    print("=" * 45)
    print("You are X. The computer is O.")
    print("The AI uses the Minimax algorithm.")

    while True:
        display_board(board)
        player_move(board)

        result = winner(board)
        if result:
            break

        ai_move(board)
        print("AI has made its move.")

        result = winner(board)
        if result:
            break

    display_board(board)

    if result == "X":
        print("Congratulations! You won!")
    elif result == "O":
        print("AI wins. Better luck next time!")
    else:
        print("It's a draw!")


if __name__ == "__main__":
    main()
