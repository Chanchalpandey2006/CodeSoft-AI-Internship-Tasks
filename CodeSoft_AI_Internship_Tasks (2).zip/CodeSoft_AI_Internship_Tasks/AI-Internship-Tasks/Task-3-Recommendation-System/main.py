"""
CodeSoft AI Internship - Task 3
Content-Based Movie Recommendation System
"""

MOVIES = {
    "3 Idiots": ["Comedy", "Drama"],
    "Chhichhore": ["Comedy", "Drama"],
    "Taare Zameen Par": ["Drama", "Education"],
    "Dangal": ["Sports", "Drama"],
    "Mary Kom": ["Sports", "Biography"],
    "Bhaag Milkha Bhaag": ["Sports", "Biography"],
    "Zindagi Na Milegi Dobara": ["Comedy", "Drama"],
    "Dil Chahta Hai": ["Comedy", "Drama"],
    "Yeh Jawaani Hai Deewani": ["Romance", "Drama"],
    "Wake Up Sid": ["Comedy", "Drama"],
    "Chak De India": ["Sports", "Drama"],
}


def recommend_movies(selected_movie):
    selected_genres = set(MOVIES[selected_movie])
    scored = []

    for movie, genres in MOVIES.items():
        if movie == selected_movie:
            continue

        common = selected_genres.intersection(genres)
        if common:
            # More shared genres = stronger recommendation.
            scored.append((len(common), movie))

    scored.sort(key=lambda item: (-item[0], item[1]))
    return [movie for _, movie in scored]


def main():
    print("=" * 55)
    print("           MOVIE RECOMMENDATION SYSTEM")
    print("=" * 55)

    print("\nAvailable movies:")
    for movie in MOVIES:
        print("-", movie)

    while True:
        choice = input("\nEnter a movie name (or type 'exit'): ").strip()

        if choice.lower() == "exit":
            print("Thank you for using the Recommendation System!")
            break

        if choice not in MOVIES:
            print("Movie not found. Please enter a movie exactly as shown.")
            continue

        recommendations = recommend_movies(choice)

        print(f"\nRecommendations similar to '{choice}':")
        if recommendations:
            for movie in recommendations:
                print("-", movie)
        else:
            print("No similar movies found.")


if __name__ == "__main__":
    main()
