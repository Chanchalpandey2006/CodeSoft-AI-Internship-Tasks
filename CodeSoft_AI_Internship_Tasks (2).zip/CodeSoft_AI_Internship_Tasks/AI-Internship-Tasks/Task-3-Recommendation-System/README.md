# Task 3 - Recommendation System

A simple **content-based movie recommendation system** written in Python.

## How It Works
Each movie is represented by a set of genres. When the user selects a movie, the system compares its genres with other movies and recommends titles with matching genres.

## Features
- Movie selection
- Genre-based recommendations
- Similarity scoring using common genres
- Sorted recommendations
- Input validation and exit option

## How to Run

```bash
python main.py
```

## Concepts Used
- Content-based filtering
- Set intersection
- Similarity scoring
- Sorting
- Functions and dictionaries
