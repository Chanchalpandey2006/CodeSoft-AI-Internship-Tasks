# CodeSoft AI Internship Projects

This repository contains completed AI internship tasks implemented in Python.

## Projects

1. **Rule-Based Chatbot** - predefined conversational rules.
2. **Tic-Tac-Toe AI** - human vs computer game using Minimax.
3. **Recommendation System** - content-based movie recommendations.

Each project has its own folder and README with setup and usage instructions.

## Requirements

- Python 3.x
- No third-party packages are required for these three projects.

## Author

Chanchal Pandey
