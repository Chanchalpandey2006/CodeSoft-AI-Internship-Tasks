"""
CodeSoft AI Internship - Task 1
Rule-Based Chatbot
"""

from datetime import datetime


def get_response(user_input):
    text = user_input.lower().strip()

    if text in ("hi", "hello", "hey"):
        return "Hello! How can I help you?"
    if "how are you" in text:
        return "I'm doing great! Thanks for asking."
    if "your name" in text:
        return "I'm RuleBot, a simple rule-based chatbot."
    if "python" in text:
        return "Python is a popular programming language used in AI, data science, and web development."
    if text == "ai" or "artificial intelligence" in text:
        return "AI stands for Artificial Intelligence. It enables computers to perform tasks that normally require human intelligence."
    if "time" in text:
        return f"The current time is {datetime.now().strftime('%H:%M:%S')}."
    if "date" in text:
        return f"Today's date is {datetime.now().strftime('%d-%m-%Y')}."
    if "thank" in text:
        return "You're welcome!"
    if "help" in text:
        return "You can ask me about Python, AI, my name, the date, or the time."
    if text in ("bye", "exit", "quit"):
        return "Goodbye! Have a nice day."

    return "Sorry, I don't understand that. Please try another question."


def main():
    print("=" * 50)
    print("          RULE-BASED CHATBOT")
    print("=" * 50)
    print("Type 'bye' to end the conversation.\n")

    while True:
        user_input = input("You: ")
        response = get_response(user_input)
        print("Bot:", response)

        if user_input.lower().strip() in ("bye", "exit", "quit"):
            break


if __name__ == "__main__":
    main()
