# Task 1 - Rule-Based Chatbot

A simple Python chatbot that responds to user messages using predefined rules and `if` conditions.

## Features
- Greeting responses
- Basic AI and Python questions
- Date and time responses
- Help command
- Unknown-input handling
- Exit with `bye`, `exit`, or `quit`

## How to Run

```bash
python main.py
```

## Concepts Used
- Conditional statements
- String matching
- Functions
- Loops
- Basic natural language processing concepts
